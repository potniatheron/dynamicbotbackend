#include "MerkelMain.hpp"
#include "Wallet.hpp"
#include <iostream>

int main() {
  MerkelMain app{};
  app.init();
}
